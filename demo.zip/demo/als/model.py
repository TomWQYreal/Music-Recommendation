# since MAP is extremely slow, we separate it to two py files.
from pyspark.ml.recommendation import ALS, ALSModel
from pyspark.mllib.evaluation import RankingMetrics
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import time
import os
import  gc
email = os.environ['USER']

spark = SparkSession.builder.appName('model').getOrCreate()
train_df = spark.read.parquet(f'hdfs:/user/{email}/train_als.parquet')
print('data imported')

# rank_dimension = [10, 50]
# alpha = [0.05, 0.5, 5]
# regularization = [0.1, 0.0001, 0.0005]

rank_dimension = [10,50]
alpha = [0.05,0.5,5]
regularization = [0.3,0.2,0.1,0.0001,0.0005]

# set iteration
iteration = 5

for ranki in rank_dimension:
    for alphai in alpha:
        for regularizationi in regularization:
            print('Hyperparameter: ', 'rank', ranki, 'alpha', alphai, 'regularization', regularizationi)
            start = time.time()
            model=ALS(userCol = 'user_id', itemCol = 'msid_idx', ratingCol = 'count', coldStartStrategy = "drop", maxIter = iteration, regParam = regularizationi, rank = ranki, alpha = alphai, nonnegative = True, checkpointInterval = 1)
            model = model.fit(train_df)
            end = time.time()
            print("Time:", end-start)
            path = f'hdfs:/user/{email}/10000/rank{ranki}_alpha{alphai}_regularization{regularizationi}'
            model.write().overwrite().save(path)
            del model
            gc.collect()
            print('finish')
print('Done')