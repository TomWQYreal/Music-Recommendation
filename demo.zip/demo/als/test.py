# prediction
# since MAP is extremely slow, we separate it to two py files.
from pyspark.ml.recommendation import ALSModel
from pyspark.mllib.evaluation import RankingMetrics
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.ml.evaluation import RankingEvaluator
from pyspark.sql.types import ArrayType, DoubleType,IntegerType
import os
import time
import gc

email = os.environ['USER']

spark = SparkSession.builder.appName('ALS').getOrCreate()
# set Hyperparameter
rank_dimension = [10, 50]
alpha = [0.05, 0.5, 5]
regularization = [0.1, 0.0001, 0.0005]

for ranki in rank_dimension:
    for alphai in alpha:
        for regularizationi in regularization:
            start = time.time()
            test_df = spark.read.parquet(f'hdfs:/user/{email}/test_als.parquet')
            print('data imported')
            print('Hyperparameter: ', 'rank', ranki, 'alpha', alphai, 'regularization', regularizationi)
            path = f'hdfs:/user/{email}/10000/rank{ranki}_alpha{alphai}_regularization{regularizationi}'
            model = ALSModel.load(path)
            print('model loaded')
            recommendation = model.recommendForAllUsers(100)
            recommendation = recommendation.selectExpr("user_id", "explode(recommendations)").select("user_id", "col.*").drop('rating')
            recommendation = recommendation.groupBy("user_id").agg(collect_list("msid_idx").alias("recommendation"))
            test_df = recommendation.join(test_df, 'user_id', 'inner').select('recommendation','msid_idx_first_100')
            del recommendation
            gc.collect()
            print('MAP')
            test_df = test_df.rdd.map(lambda row: (row[0], row[1]))
            metrics = RankingMetrics(test_df)
            mean_average_precision = metrics.meanAveragePrecision
            end = time.time()
            print("MAP: ", mean_average_precision)
            print("Time:", end-start)

print('Done')

            # # rename for join
            # recommendation = recommendation.withColumnRenamed("recommendation", "msid_idx")
            # # drop unrelated msid
            # val_set = val_df.join(recommendation, ['user_id','msid_idx'], 'inner').repartition('user_id')
            # recommendation = recommendation.groupBy("user_id").agg(collect_list("msid_idx").alias("recommendation"))
            # val_set = val_set.groupBy("user_id").agg(collect_list("msid_idx").alias("actual"))
            # predictionsAndLabels = recommendation.join(val_set, 'user_id', 'inner').rdd.map(lambda row: (row[1], row[2])).repartition(100)



            # result = val_df.join(recommendation, "user_id", 'inner').drop("user_id")

            # val_df = val_df.withColumn('actual', array_intersect(col('recommendation'), col('msid_idx'))).select('recommendation','actual')
            # val_df = val_df.withColumn('actual', when(size(col('actual')) > 0, col('actual')).otherwise(array(lit(-1))))
            # val_df = val_df.filter(size(col('actual')) > 0)



            # print(1)
            # convert_to_double_udf = udf(lambda x: [float(i) for i in x], ArrayType(DoubleType()))
            # print(2)
            # predictionsAndLabels = predictionsAndLabels.withColumn("prediction", convert_to_double_udf("recommendation")).drop('recommendation')
            # print(3)
            # predictionsAndLabels = predictionsAndLabels.withColumn("actuals", convert_to_double_udf("actual")).drop('actual')
            # print(4)
            # # Use RankingEvaluator to calculate MAP
            # evaluator = RankingEvaluator(predictionCol="prediction", labelCol="actuals", metricName="meanAveragePrecision")
            # print(5)
            # mean_average_precision = evaluator.evaluate(predictionsAndLabels)
            # print(6)

            # def flatten_list(l):
            #     return [item for sublist in l for item in sublist]
            # flatten_udf = udf(flatten_list, ArrayType(IntegerType()))
            # result = result.withColumn("actuals", flatten_udf("actual"))
            # print(1)
            # predictionAndLabels = result.select("recommendation", "actuals").rdd.map(lambda x: (x[0], x[1]))
            # print(2)
            # predictionsAndLabels = predictionsAndLabels.rdd
