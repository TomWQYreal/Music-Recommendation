from pyspark import SparkConf
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.window import Window
import os
from pyspark.sql import SparkSession
from pyspark.sql.functions import collect_list,sum,mean,col,desc,row_number, desc,lit,create_map,array,udf,flatten,transform,arrays_zip
import collections
from pyspark.sql.window import Window
from pyspark.mllib.evaluation import RankingMetrics
from pyspark.ml.evaluation import RankingEvaluator
from pyspark.sql.types import ArrayType, DoubleType,IntegerType

#import spark
spark = SparkSession.builder.appName('preprocessing').getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

# Read a Parquet file into a DataFrame
train_df = spark.read.parquet('hdfs:/user/jh8530_nyu_edu/train_als.parquet')
val_df = spark.read.parquet('hdfs:/user/jh8530_nyu_edu/val_als.parquet')
#print('Printing train_df')
#train_df.show(10)
# print('Printing val_df')
# val_df.show(10)

train_df.createOrReplaceTempView("train_table")

print('R[u,i] sum result: ')
R_counts = spark.sql("""
        SELECT msid_idx, COUNT(DISTINCT user_id) AS R_counts
        FROM train_table
        GROUP BY msid_idx
""")
#R_counts.show(10)

print('R[:,i] sum result: ')
r_item = spark.sql("""
        SELECT msid_idx, SUM(count) AS r_item
        FROM train_table
        GROUP BY msid_idx
""")
#r_item.show(10)
# test the total of r_item
# r_item.createOrReplaceTempView("item_test")
# item_total_test = spark.sql("SELECT SUM(r_item) FROM item_test").collect()[0][0]
# print('item_total_test: ')
# print(item_total_test)

R_counts.createOrReplaceTempView("R_counts_table")
r_item.createOrReplaceTempView("r_item_table")

print('join the two table:')
join = spark.sql("""
        SELECT R_counts_table.msid_idx, R_counts_table.R_counts, r_item_table.r_item
        FROM R_counts_table
        JOIN r_item_table
        ON R_counts_table.msid_idx = r_item_table.msid_idx
""")
join.show(2)

#top 100 based on probability
join.createOrReplaceTempView("join_table")
print("calculate probability: ")
#beta = 10000000 (added below)
msid_train_top100 = []
result = spark.sql("""
        SELECT msid_idx, R_counts, r_item, R_counts/(r_item+2000000) AS probability
        FROM join_table
        ORDER BY probability DESC
        LIMIT 100
""")  
result.show(2)
result_list = result.collect()
# Iterate over the rows in the result table and append the recording_msid values to the list
for row in result_list:
    msid_train_top100.append(row['msid_idx'])
#print(msid_train_top100)

print("validation data with top 100 msid: ")
val_df.createOrReplaceTempView("val_table")
# val_result = spark.sql("""
#         SELECT user_id, COLLECT_LIST(recording_msid_top100) AS msid_val_top100
#         FROM (
#         SELECT user_id, recording_msid_top100, ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY count DESC) AS rank
#         FROM (
#         SELECT user_id, recording_msid, SUM(count) AS count, 
#                 COLLECT_LIST(recording_msid) OVER (PARTITION BY user_id ORDER BY SUM(count) DESC ROWS BETWEEN UNBOUNDED PRECEDING AND 99 FOLLOWING) AS recording_msid_top100
#         FROM val_table
#         GROUP BY user_id, recording_msid
#         ) t
#         ) t2
#         WHERE rank <= 100
#         GROUP BY user_id
#         HAVING SIZE(msid_val_top100) >= 100
# """)
val_result = spark.sql("""
    SELECT user_id, COLLECT_LIST(msid_idx) AS msid_val_top100
    FROM (
        SELECT user_id, msid_idx, count, ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY count DESC) AS rank
        FROM (
            SELECT user_id, msid_idx, SUM(count) AS count
            FROM val_table
            GROUP BY user_id, msid_idx
        ) t
    ) t2
    WHERE rank <= 100
    GROUP BY user_id
    HAVING SIZE(msid_val_top100) >= 100
""")
val_result.show(2)

print('flatten val_top 100 list:')
val_result_df = val_result.withColumn("msid_train_top100", array([lit(x) for x in msid_train_top100]))

# def flatten_list(l):
#     return [item for sublist in l for item in sublist]

# flatten_udf = udf(flatten_list, ArrayType(IntegerType()))

# val_result_df_new = val_result_df.withColumn("msid_val_top100_flat", flatten_udf("msid_val_top100"))

# val_result_df_new.show(2)


# #-----calculate MAP value: method (rankingevaluator)---

print("MAP are: ")

# val_result_df_10 = val_result_df_new
# convert_to_double_udf = udf(lambda x: [float(i) for i in x], ArrayType(DoubleType()))
# val_result_df_10 = val_result_df_10.withColumn("msid_train_top100_double", convert_to_double_udf("msid_train_top100"))
# val_result_df_10 = val_result_df_10.withColumn("msid_val_top100_double", convert_to_double_udf("msid_val_top100_flat"))

# # Use RankingEvaluator to calculate MAP
# evaluator = RankingEvaluator(predictionCol="msid_train_top100_double", labelCol="msid_val_top100_double", metricName="meanAveragePrecision")
# mean_average_precision = evaluator.evaluate(val_result_df_10)

# print("Mean Average Precision: ")
# print(mean_average_precision)

# #-----calculate MAP value: method (ranking metrics)---
predictionAndLabels = val_result_df.select("msid_train_top100", "msid_val_top100").rdd.map(lambda x: (x[0], x[1]))

# create a RankingMetrics object
metrics = RankingMetrics(predictionAndLabels)

# calculate mean average precision
mean_average_precision = metrics.meanAveragePrecision


print("Mean Average Precision: ")
print(mean_average_precision)