from pyspark import SparkConf
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql import SparkSession
from pyspark.mllib.evaluation import RankingMetrics
from pyspark.ml.evaluation import RankingEvaluator
from pyspark.sql.types import ArrayType, DoubleType,IntegerType
import os
email = os.environ['USER']

#import spark
spark = SparkSession.builder.appName('baseline').getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

# Read a Parquet file into a DataFrame
train_df = spark.read.parquet(f'hdfs:/user/{email}/train_als.parquet')
train_df.createOrReplaceTempView("train_table")
beta = 500000
print('Beta is:', beta)
sql_query = """
SELECT msid_idx, (COUNT(DISTINCT user_id)/(SUM(count) + {Beta})) AS probability
FROM train_table
GROUP BY msid_idx
ORDER BY probability DESC
LIMIT 100
        """
sql_query = sql_query.format(Beta = beta)
train_df = spark.sql(sql_query)
train_df = train_df.select('msid_idx').collect()
#top 100 based on probability
msid_train_top100 = [x.msid_idx for x in train_df]

test_df = spark.read.parquet(f'hdfs:/user/{email}/test_als.parquet')
# test_df.createOrReplaceTempView("test_table")
# val_result = spark.sql("""
#         SELECT user_id, COLLECT_LIST(recording_msid_top100) AS msid_val_top100
#         FROM (
#         SELECT user_id, recording_msid_top100, ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY count DESC) AS rank
#         FROM (
#         SELECT user_id, recording_msid, SUM(count) AS count, 
#                 COLLECT_LIST(recording_msid) OVER (PARTITION BY user_id ORDER BY SUM(count) DESC ROWS BETWEEN UNBOUNDED PRECEDING AND 99 FOLLOWING) AS recording_msid_top100
#         FROM val_table
#         GROUP BY user_id, recording_msid
#         ) t
#         ) t2
#         WHERE rank <= 100
#         GROUP BY user_id
#         HAVING SIZE(msid_val_top100) >= 100
# """)
# test_df = spark.sql("""
#     SELECT user_id, COLLECT_LIST(msid_idx) AS msid_val_top100
#     FROM test_table
#     GROUP BY user_id
# """)

# print('flatten val_top 100 list:')
test_df = test_df.withColumn("msid_train_top100", array([lit(x) for x in msid_train_top100]))

# def flatten_list(l):
#     return [item for sublist in l for item in sublist]

# flatten_udf = udf(flatten_list, ArrayType(IntegerType()))

# val_result_df_new = val_result_df.withColumn("msid_val_top100_flat", flatten_udf("msid_val_top100"))

# val_result_df_new.show(2)


# #-----calculate MAP value: method (rankingevaluator)---

# print("MAP are: ")

# val_result_df_10 = val_result_df_new
# convert_to_double_udf = udf(lambda x: [float(i) for i in x], ArrayType(DoubleType()))
# val_result_df_10 = val_result_df_10.withColumn("msid_train_top100_double", convert_to_double_udf("msid_train_top100"))
# val_result_df_10 = val_result_df_10.withColumn("msid_val_top100_double", convert_to_double_udf("msid_val_top100_flat"))

# # Use RankingEvaluator to calculate MAP
# evaluator = RankingEvaluator(predictionCol="msid_train_top100_double", labelCol="msid_val_top100_double", metricName="meanAveragePrecision")
# mean_average_precision = evaluator.evaluate(val_result_df_10)

# print("Mean Average Precision: ")
# print(mean_average_precision)

# #-----calculate MAP value: method (ranking metrics)---
predictionAndLabels = test_df.select("msid_train_top100", "actual").rdd.map(lambda x: (x[0], x[1]))

# create a RankingMetrics object
metrics = RankingMetrics(predictionAndLabels)

# calculate mean average precision
mean_average_precision = metrics.meanAveragePrecision


print("Test Mean Average Precision: ", mean_average_precision)
print('Done')