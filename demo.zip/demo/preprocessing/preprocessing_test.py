# Preprocessing
# I checked that there is no empty element in interactions, and no known duplication row for tracks's training set
# import packages
from pyspark import SparkConf
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.window import Window
import os
email = os.environ['USER']

# Create the spark session object
spark = SparkSession.builder.appName('preprocessing').getOrCreate()
spark.sparkContext.setLogLevel("ERROR")
# Load track: ./tracks_train.parquet or hdfs:/user/bm106_nyu_edu/1004-project-2023/tracks_train.parquet
track_dictionary = spark.read.parquet(f'hdfs:/user/{email}/track_dict.parquet')
# track_dictionary = track_dictionary.select("recording_msid","msid_idx")
# Load interaction: ./interaction_small.parquet or hdfs:/user/bm106_nyu_edu/1004-project-2023/interactions_train.parquet
interaction_test = spark.read.parquet('hdfs:/user/bm106_nyu_edu/1004-project-2023/interactions_test.parquet')
train_df = spark.read.parquet(f'hdfs:/user/{email}/train_als.parquet')
train_df = train_df.groupBy("user_id").agg(collect_list("msid_idx").alias("all"))
# drop unrelated column and comvert recording_msid to msid_idx
interaction_test = interaction_test.select("user_id", "recording_msid")
interaction_test = interaction_test.join(track_dictionary, "recording_msid", "left_outer")
interaction_test = interaction_test.drop("recording_msid")
# add count and sort dataset, then collect_list
interaction_test = interaction_test.groupBy("user_id", "msid_idx").agg(count("*").alias("count"))
interaction_test = interaction_test.orderBy(['user_id', 'count'], ascending=[True, False]).drop('count')
interaction_test = interaction_test.groupBy("user_id").agg(collect_list("msid_idx").alias("msid_idx"))
interaction_test = interaction_test.join(train_df, 'user_id', 'inner')
interaction_test = interaction_test.withColumn('msid_idx', array_intersect(col('all'), col('msid_idx'))).select('user_id','msid_idx')
interaction_test1 = interaction_test.select ("user_id", explode ("msid_idx").alias ("msid_idx"))
print(interaction_test1.count(),'4296493')
interaction_test1.write.format("csv").mode("overwrite").option("header", "true").save(f'hdfs:/user/{email}/test.csv')
interaction_test = interaction_test.select("user_id", slice("msid_idx", 1, 100).alias("msid_idx_first_100"))
print(interaction_test.count(),'3323')
interaction_test.write.mode("overwrite").parquet(f'hdfs:/user/{email}/test_als.parquet')

print('Done')

