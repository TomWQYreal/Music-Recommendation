# import packages
from pyspark import SparkConf
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.window import Window
from pyspark.sql.functions import slice

import os
email = os.environ['USER']

# Create the spark session object
spark = SparkSession.builder.appName('split').getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

interaction_train = spark.read.parquet(f'hdfs:/user/{email}/interaction_train.parquet')
interaction_train = interaction_train.filter(col("usid_count")>10000).drop('usid_count')
# distinct_count = interaction_train.select(countDistinct("user_id")).collect()[0][0]
# random split data to 80%-20% train-val, for each user_id
train_df = interaction_train.sampleBy("user_id", fractions={user_id: 0.8 for user_id in interaction_train.select("user_id").distinct().rdd.map(lambda x: x[0]).collect()},seed = 42)
# distinct_train = interaction_train.select(countDistinct("user_id")).collect()[0][0]
val_df = interaction_train.exceptAll(train_df)
# distinct_val = interaction_train.select(countDistinct("user_id")).collect()[0][0]
print(train_df.count()+val_df.count(),'168547064')

train_df.createOrReplaceTempView("train_df_table")

train_df = spark.sql("""
        SELECT user_id, msid_idx, COUNT(*) AS count
        FROM train_df_table
        GROUP BY user_id, msid_idx
        ORDER BY user_id, count(*) DESC;
""")
train_df = train_df.select('user_id','msid_idx')             
# train_df.write.mode("overwrite").parquet(f'hdfs:/user/{email}/train_als.parquet')
# train_df.coalesce(1).write.mode("overwrite").csv(f"hdfs:/user/{email}/train.csv", header=True)

val_df.createOrReplaceTempView("val_df_table")

val_df = spark.sql("""
        SELECT user_id, msid_idx, COUNT(*) AS count
        FROM val_df_table
        GROUP BY user_id, msid_idx
        ORDER BY user_id, count(*) DESC;
""")
val_df = val_df.join(train_df, on=["user_id","msid_idx"])

val_df.coalesce(1).write.mode("overwrite").csv(f"hdfs:/user/{email}/val_count.csv", header=True)

# val_df = val_df.groupBy("user_id").agg(collect_list("msid_idx").alias("msid_idx"))
# val_df = val_df.join(train_df, 'user_id', 'inner')
# # prevent cold_start
# val_df = val_df.withColumn('msid_idx', array_intersect(col('all'), col('msid_idx'))).select('user_id','msid_idx')
# val_df = val_df.select ("user_id", explode ("msid_idx").alias ("msid_idx"))
# val_df.coalesce(1).write.mode("overwrite").csv(f"hdfs:/user/{email}/val.csv", header=True)
# print(val_df1.count(),'12328599')
# val_df1.write.format("csv").mode("overwrite").option("header", "true").save(f'hdfs:/user/{email}/val.csv')
# top 100 val
# val_df = val_df.select("user_id", slice("msid_idx", 1, 100).alias("msid_idx_first_100"))
print(val_df.count(),'4250')
# val_df.write.mode("overwrite").parquet(f'hdfs:/user/{email}/val_als.parquet')
print('Done')
