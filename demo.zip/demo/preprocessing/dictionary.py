# Preprocessing
# I checked that there is no empty element in interactions, and no known duplication row for tracks's training set

# import packages
from pyspark import SparkConf
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.window import Window
from pyspark.sql.functions import col
import os
email = os.environ['USER']



# Create the spark session object
spark = SparkSession.builder.appName('dictionary').getOrCreate()
spark.sparkContext.setLogLevel("ERROR")
# Load track: ./tracks_train.parquet or hdfs:/user/bm106_nyu_edu/1004-project-2023/tracks_train.parquet
track_train = spark.read.parquet('hdfs:/user/bm106_nyu_edu/1004-project-2023/tracks_train.parquet')
track_train = track_train.select("recording_msid", "recording_mbid")

# Load track: ./tracks_test.parquet or hdfs:/user/bm106_nyu_edu/1004-project-2023/tracks_test.parquet
track_test = spark.read.parquet('hdfs:/user/bm106_nyu_edu/1004-project-2023/tracks_test.parquet')
track_test = track_test.select("recording_msid", "recording_mbid")
# It is not using test dataset. Instead, it is creating a string to idx dictionary.
# # only this method can make sure the id is unique and the same for train and val and test.
# drop extra recording_msid that one recording_msid have multiple recording_mbid
track_stringtoidx = track_train.union(track_test).dropDuplicates(["recording_msid"])
track_stringtoidx = track_stringtoidx.withColumn("recording_mbid", when(col("recording_mbid").isNull(), col("recording_msid")).otherwise(col("recording_mbid")))
# for all same recording_mbid, msid_idx will be the same
track_stringtoidx = track_stringtoidx.withColumn("msid_idx", row_number().over(Window.orderBy("recording_mbid")))
track_stringtoidx = track_stringtoidx.drop('recording_mbid')
track_stringtoidx.write.mode("overwrite").parquet(f'hdfs:/user/{email}/track_dict.parquet')
print(track_stringtoidx.count(),'34653781')
print('Done')
