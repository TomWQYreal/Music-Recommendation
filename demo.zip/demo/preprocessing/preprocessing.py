# Preprocessing
# I checked that there is no empty element in interactions, and no known duplication row for tracks's training set
# import packages
from pyspark import SparkConf
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.window import Window
import os
import gc
email = os.environ['USER']

# Create the spark session object
spark = SparkSession.builder.appName('preprocessing').getOrCreate()
spark.sparkContext.setLogLevel("ERROR")
# Load track: ./tracks_train.parquet or hdfs:/user/bm106_nyu_edu/1004-project-2023/tracks_train.parquet
track_dictionary = spark.read.parquet(f'hdfs:/user/{email}/track_dict.parquet')
# track_dictionary = track_dictionary.select("recording_msid","msid_idx")
# Load interaction: ./interaction_small.parquet or hdfs:/user/bm106_nyu_edu/1004-project-2023/interactions_train.parquet
interaction_train = spark.read.parquet('hdfs:/user/bm106_nyu_edu/1004-project-2023/interactions_train.parquet')
interaction_train = interaction_train.select("user_id", "recording_msid")
interaction_train = interaction_train.join(track_dictionary, on = "recording_msid", how =  "left_outer")
interaction_train = interaction_train.drop("recording_msid")
print(interaction_train.count(),'179466123')
del track_dictionary
gc.collect()
# add count for interaction for each user
interaction_train = interaction_train.withColumn("usid_count", count("msid_idx").over(Window.partitionBy("user_id")))
print(interaction_train.count(),'179466123')
interaction_train.write.mode("overwrite").parquet(f'hdfs:/user/{email}/interaction_train.parquet')
print('Done')


